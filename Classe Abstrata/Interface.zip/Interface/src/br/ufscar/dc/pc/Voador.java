package br.ufscar.dc.pc;

public interface Voador {
    void decolar();

    void aterissar();
}
