package br.ufscar.dc.pc;


public class Passarinho implements Voador {

    public void decolar() {
        System.out.println("Bate as asas e levanta voo");
    }

    public void aterissar() {
        System.out.println("Fechas as asas");
    }
}
