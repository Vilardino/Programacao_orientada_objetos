package br.ufscar.dc.pc;


public interface MeioDeTransporte {

    void subir();

    void descer();
}
