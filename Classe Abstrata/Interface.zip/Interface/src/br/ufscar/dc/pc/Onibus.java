package br.ufscar.dc.pc;


public class Onibus implements MeioDeTransporte{

    public void subir() {
        System.out.println("O onibus para no ponto e pessoal sobe");
    }

    public void descer() {
        System.out.println("O onibus para no ponto e pessoal desce");
    }


}
